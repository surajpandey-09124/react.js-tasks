// main.jsx (ALL IN ONE - Grocify UI with Tailwind)

import React, { useState } from "react";
import ReactDOM from "react-dom/client";
import "./style.css";

/* -------- NAVBAR -------- */

function Navbar() {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");

  return (
    <nav className="nav">
      <h2 className="logo">Grocify Website</h2>

      <div className={open ? "menu show" : "menu"}>
        <a href="#">Home</a>
        <a href="#">About Us</a>
        <a href="#">Process</a>
        <a href="#">Contact Us</a>
      </div>

      <div className="right">
        <input
          placeholder="Search..."
          onChange={(e) => setSearch(e.target.value)}
        />
        <button onClick={() => console.log(search)}>🔍</button>

        <span>❤️</span>
        <span>🛒</span>

        <button className="hamburger" onClick={() => setOpen(!open)}>
          ☰
        </button>
      </div>
    </nav>
  );
}

/* -------- HERO -------- */

function Hero() {
  return (
    <section className="hero">
      <div className="left">
        <span className="badge">Export Best Quality...</span>

        <h1>
          Tasty Organic <br />
          Fruits & Veggies <br />
          <span>In Your City</span>
        </h1>

        <p>
          Fresh organic fruits and vegetables delivered to your doorstep.
        </p>

        <button className="btn">Shop Now</button>
      </div>

      <div className="right">
        <img
          src="https://pngimg.com/uploads/fruit_basket/fruit_basket_PNG33.png"
          alt="basket"
        />
      </div>
    </section>
  );
}

/* -------- APP -------- */

function App() {
  return (
    <>
      <Navbar />
      <Hero />
    </>
  );
}

/* -------- RENDER -------- */

ReactDOM.createRoot(document.getElementById("root")).render(<App />);