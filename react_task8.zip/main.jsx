// main.jsx (ALL IN ONE - Routing + Auth + Protected + Dynamic + Test Component)

import React, { useState, createContext, useContext } from "react";
import ReactDOM from "react-dom/client";
import {
  BrowserRouter,
  Routes,
  Route,
  Link,
  Navigate,
  useParams
} from "react-router-dom";
import "./style.css";

/* -------- AUTH CONTEXT -------- */

const AuthContext = createContext();

function AuthProvider({ children }) {
  const [user, setUser] = useState(null);

  const login = (email) => setUser({ email });
  const logout = () => setUser(null);

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

const useAuth = () => useContext(AuthContext);

/* -------- PROTECTED ROUTE -------- */

function Protected({ children }) {
  const { user } = useAuth();
  return user ? children : <Navigate to="/login" />;
}

/* -------- PAGES -------- */

function Home() {
  return <h2>Home Page</h2>;
}

function About() {
  return <h2>About Page</h2>;
}

function Login() {
  const [email, setEmail] = useState("");
  const { login } = useAuth();

  return (
    <div>
      <h2>Login</h2>
      <input placeholder="Email" onChange={e => setEmail(e.target.value)} />
      <button onClick={() => login(email)}>Login</button>
    </div>
  );
}

function Signup() {
  return <h2>Signup Page</h2>;
}

function Dashboard() {
  const { user, logout } = useAuth();

  return (
    <div>
      <h2>Dashboard</h2>
      <p>{user?.email}</p>
      <button onClick={logout}>Logout</button>
    </div>
  );
}

function Profile() {
  const { userId } = useParams();
  return <h2>Profile ID: {userId}</h2>;
}

function NotFound() {
  return <h2>404 Page Not Found</h2>;
}

/* -------- NAVBAR -------- */

function Navbar() {
  return (
    <nav>
      <Link to="/">Home</Link>
      <Link to="/about">About</Link>
      <Link to="/login">Login</Link>
      <Link to="/dashboard">Dashboard</Link>
      <Link to="/profile/123">Profile</Link>
    </nav>
  );
}

/* -------- COUNTER (TESTABLE) -------- */

function Counter() {
  const [count, setCount] = useState(0);

  return (
    <div>
      <h3>{count}</h3>
      <button onClick={() => setCount(count + 1)}>+</button>
      <button onClick={() => setCount(count - 1)}>-</button>
    </div>
  );
}

/* -------- APP -------- */

function App() {
  return (
    <BrowserRouter>
      <Navbar />

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />

        <Route
          path="/dashboard"
          element={
            <Protected>
              <Dashboard />
            </Protected>
          }
        />

        <Route path="/profile/:userId" element={<Profile />} />
        <Route path="*" element={<NotFound />} />
      </Routes>

      <Counter />
    </BrowserRouter>
  );
}

/* -------- RENDER -------- */

ReactDOM.createRoot(document.getElementById("root")).render(
  <AuthProvider>
    <App />
  </AuthProvider>
);