// main.jsx (ALL IN ONE - Redux Toolkit App)

import React, { useState } from "react";
import ReactDOM from "react-dom/client";
import { Provider, useDispatch, useSelector } from "react-redux";
import { configureStore, createSlice } from "@reduxjs/toolkit";
import "./style.css";

/* -------- userSlice -------- */

const userSlice = createSlice({
  name: "user",
  initialState: {
    name: "",
    email: "",
    success: false
  },
  reducers: {
    signup: (state, action) => {
      state.name = action.payload.name;
      state.email = action.payload.email;
      state.success = true;
    }
  }
});

/* -------- pizzaSlice -------- */

const pizzaSlice = createSlice({
  name: "pizza",
  initialState: {
    size: "small",
    toppings: []
  },
  reducers: {
    setSize: (state, action) => {
      state.size = action.payload;
    },
    toggleTopping: (state, action) => {
      if (state.toppings.includes(action.payload)) {
        state.toppings = state.toppings.filter(t => t !== action.payload);
      } else {
        state.toppings.push(action.payload);
      }
    }
  }
});

/* -------- cartSlice -------- */

const cartSlice = createSlice({
  name: "cart",
  initialState: {
    items: []
  },
  reducers: {
    addToCart: (state, action) => {
      state.items.push(action.payload);
    },
    removeFromCart: (state, action) => {
      state.items = state.items.filter((_, i) => i !== action.payload);
    },
    clearCart: (state) => {
      state.items = [];
    }
  }
});

/* -------- store -------- */

const store = configureStore({
  reducer: {
    user: userSlice.reducer,
    pizza: pizzaSlice.reducer,
    cart: cartSlice.reducer
  }
});

/* -------- Signup -------- */

function Signup() {
  const dispatch = useDispatch();
  const success = useSelector(s => s.user.success);

  const [form, setForm] = useState({ name: "", email: "" });

  return (
    <div className="box">
      <h2>Signup</h2>

      <input
        placeholder="Name"
        onChange={e => setForm({ ...form, name: e.target.value })}
      />

      <input
        placeholder="Email"
        onChange={e => setForm({ ...form, email: e.target.value })}
      />

      <button onClick={() => dispatch(userSlice.actions.signup(form))}>
        Submit
      </button>

      {success && <p className="success">Signup Success ✅</p>}
    </div>
  );
}

/* -------- Pizza -------- */

function Pizza() {
  const dispatch = useDispatch();
  const pizza = useSelector(s => s.pizza);
  const cart = useSelector(s => s.cart.items);

  const prices = { small: 100, medium: 200, large: 300 };

  const total =
    (prices[pizza.size] + pizza.toppings.length * 20);

  return (
    <div className="box">
      <h2>Pizza</h2>

      <select onChange={e => dispatch(pizzaSlice.actions.setSize(e.target.value))}>
        <option value="small">Small</option>
        <option value="medium">Medium</option>
        <option value="large">Large</option>
      </select>

      <div>
        <label>
          <input type="checkbox" onChange={() => dispatch(pizzaSlice.actions.toggleTopping("Cheese"))} />
          Cheese
        </label>

        <label>
          <input type="checkbox" onChange={() => dispatch(pizzaSlice.actions.toggleTopping("Paneer"))} />
          Paneer
        </label>
      </div>

      <h3>Price: ₹{total}</h3>

      <button onClick={() => dispatch(cartSlice.actions.addToCart({ ...pizza, price: total }))}>
        Add to Cart
      </button>

      <h3>Cart</h3>

      {cart.map((c, i) => (
        <div key={i} className="item">
          <span>{c.size} - ₹{c.price}</span>
          <button onClick={() => dispatch(cartSlice.actions.removeFromCart(i))}>
            Delete
          </button>
        </div>
      ))}

      <button onClick={() => dispatch(cartSlice.actions.clearCart())}>
        Clear Cart
      </button>
    </div>
  );
}

/* -------- App -------- */

function App() {
  return (
    <>
      <Signup />
      <Pizza />
    </>
  );
}

/* -------- Render -------- */

ReactDOM.createRoot(document.getElementById("root")).render(
  <Provider store={store}>
    <App />
  </Provider>
);