// main.jsx (ALL IN ONE - Context + Reducer + Components)

import React, { createContext, useReducer, useContext, useState } from "react";
import ReactDOM from "react-dom/client";
import "./App.css";

/* -------- CONTEXT -------- */

const TaskContext = createContext();

const initialState = {
  tasks: []
};

function reducer(state, action) {
  switch (action.type) {
    case "ADD":
      return {
        tasks: [...state.tasks, { id: Date.now(), text: action.payload, done: false }]
      };

    case "TOGGLE":
      return {
        tasks: state.tasks.map(t =>
          t.id === action.payload ? { ...t, done: !t.done } : t
        )
      };

    case "DELETE":
      return {
        tasks: state.tasks.filter(t => t.id !== action.payload)
      };

    case "EDIT":
      return {
        tasks: state.tasks.map(t =>
          t.id === action.payload.id ? { ...t, text: action.payload.text } : t
        )
      };

    case "CLEAR":
      return { tasks: [] };

    default:
      return state;
  }
}

function TaskProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, initialState);

  return (
    <TaskContext.Provider value={{ state, dispatch }}>
      {children}
    </TaskContext.Provider>
  );
}

const useTask = () => useContext(TaskContext);

/* -------- COMPONENTS -------- */

function TaskInput() {
  const [text, setText] = useState("");
  const { dispatch } = useTask();

  const addTask = () => {
    if (text.trim() === "") return;
    dispatch({ type: "ADD", payload: text });
    setText("");
  };

  return (
    <div className="inputBox">
      <input
        value={text}
        onChange={e => setText(e.target.value)}
        placeholder="Enter task..."
      />
      <button onClick={addTask}>Add</button>
    </div>
  );
}

function TaskItem({ task }) {
  const { dispatch } = useTask();
  const [edit, setEdit] = useState(false);
  const [newText, setNewText] = useState(task.text);

  return (
    <div className={task.done ? "task done" : "task"}>
      {edit ? (
        <input value={newText} onChange={e => setNewText(e.target.value)} />
      ) : (
        <span onClick={() => dispatch({ type: "TOGGLE", payload: task.id })}>
          {task.text}
        </span>
      )}

      <div>
        {edit ? (
          <button
            onClick={() => {
              dispatch({ type: "EDIT", payload: { id: task.id, text: newText } });
              setEdit(false);
            }}
          >
            Save
          </button>
        ) : (
          <button onClick={() => setEdit(true)}>Edit</button>
        )}

        <button onClick={() => dispatch({ type: "DELETE", payload: task.id })}>
          Delete
        </button>
      </div>
    </div>
  );
}

function TaskList() {
  const { state } = useTask();

  return (
    <div>
      {state.tasks.map(t => (
        <TaskItem key={t.id} task={t} />
      ))}
    </div>
  );
}

function TaskSummary() {
  const { state } = useTask();

  const total = state.tasks.length;
  const done = state.tasks.filter(t => t.done).length;

  return (
    <h3>
      Total: {total} | Completed: {done}
    </h3>
  );
}

/* -------- APP -------- */

function App() {
  const { dispatch } = useTask();

  return (
    <div className="container">
      <h1>Task Manager</h1>

      <TaskInput />
      <TaskSummary />
      <TaskList />

      <button className="clear" onClick={() => dispatch({ type: "CLEAR" })}>
        Clear All
      </button>
    </div>
  );
}

/* -------- RENDER -------- */

ReactDOM.createRoot(document.getElementById("root")).render(
  <TaskProvider>
    <App />
  </TaskProvider>
);