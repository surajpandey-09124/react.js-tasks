// main.jsx (ALL IN ONE - Registration + Pizza Form)

import React, { useState } from "react";
import ReactDOM from "react-dom/client";
import "./style.css";

/* -------- REGISTRATION FORM -------- */

function Register() {
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    password: "",
    confirm: "",
    gender: "",
    terms: false
  });

  const [success, setSuccess] = useState(false);

  const validate =
    form.name &&
    /\S+@\S+\.\S+/.test(form.email) &&
    form.phone.length === 10 &&
    form.password.length >= 6 &&
    form.password === form.confirm &&
    form.gender &&
    form.terms;

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validate) return;
    setSuccess(true);
  };

  return (
    <div className="box">
      <h2>Register</h2>

      <form onSubmit={handleSubmit}>
        <input placeholder="Name" onChange={e => setForm({ ...form, name: e.target.value })} />
        <input placeholder="Email" onChange={e => setForm({ ...form, email: e.target.value })} />
        <input placeholder="Phone" onChange={e => setForm({ ...form, phone: e.target.value })} />
        <input type="password" placeholder="Password" onChange={e => setForm({ ...form, password: e.target.value })} />
        <input type="password" placeholder="Confirm Password" onChange={e => setForm({ ...form, confirm: e.target.value })} />

        <div>
          <label><input type="radio" name="g" onChange={() => setForm({ ...form, gender: "male" })}/> Male</label>
          <label><input type="radio" name="g" onChange={() => setForm({ ...form, gender: "female" })}/> Female</label>
        </div>

        <label>
          <input type="checkbox" onChange={(e) => setForm({ ...form, terms: e.target.checked })} />
          Accept Terms
        </label>

        <button disabled={!validate}>Submit</button>
      </form>

      {success && <p className="success">Registered Successfully ✅</p>}
    </div>
  );
}

/* -------- PIZZA FORM -------- */

function Pizza() {
  const [order, setOrder] = useState({
    size: "small",
    crust: "thin",
    toppings: [],
    qty: 1
  });

  const prices = { small: 100, medium: 200, large: 300 };

  const toggleTopping = (t) => {
    setOrder({
      ...order,
      toppings: order.toppings.includes(t)
        ? order.toppings.filter(x => x !== t)
        : [...order.toppings, t]
    });
  };

  const total =
    (prices[order.size] + order.toppings.length * 20) * order.qty;

  return (
    <div className="box">
      <h2>Mario Pizza 🍕</h2>

      <select onChange={e => setOrder({ ...order, size: e.target.value })}>
        <option value="small">Small</option>
        <option value="medium">Medium</option>
        <option value="large">Large</option>
      </select>

      <select onChange={e => setOrder({ ...order, crust: e.target.value })}>
        <option>Thin</option>
        <option>Cheese Burst</option>
      </select>

      <div>
        <label><input type="checkbox" onChange={() => toggleTopping("Cheese")} /> Cheese</label>
        <label><input type="checkbox" onChange={() => toggleTopping("Corn")} /> Corn</label>
        <label><input type="checkbox" onChange={() => toggleTopping("Paneer")} /> Paneer</label>
      </div>

      <input
        type="number"
        value={order.qty}
        onChange={e => setOrder({ ...order, qty: e.target.value })}
      />

      <h3>Total: ₹{total}</h3>

      <div className="summary">
        <p>Size: {order.size}</p>
        <p>Crust: {order.crust}</p>
        <p>Toppings: {order.toppings.join(", ")}</p>
        <p>Qty: {order.qty}</p>
      </div>
    </div>
  );
}

/* -------- APP -------- */

function App() {
  return (
    <>
      <Register />
      <Pizza />
    </>
  );
}

/* -------- RENDER -------- */

ReactDOM.createRoot(document.getElementById("root")).render(<App />);