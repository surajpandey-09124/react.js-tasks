// main.jsx (ALL IN ONE - Class Components + Lifecycle)

import React from "react";
import ReactDOM from "react-dom/client";
import "./style.css";

/* -------- Student Item -------- */

class StudentItem extends React.Component {
  render() {
    const { student, onDelete, onToggle } = this.props;

    return (
      <div className={student.grade >= 50 ? "item pass" : "item fail"}>
        <span>
          {student.name} - {student.grade}
        </span>

        <div>
          <button onClick={() => onToggle(student.id)}>
            {student.grade >= 50 ? "Fail" : "Pass"}
          </button>
          <button onClick={() => onDelete(student.id)}>Delete</button>
        </div>
      </div>
    );
  }
}

/* -------- Student List -------- */

class StudentList extends React.Component {
  render() {
    return (
      <div>
        {this.props.students.map(s => (
          <StudentItem
            key={s.id}
            student={s}
            onDelete={this.props.onDelete}
            onToggle={this.props.onToggle}
          />
        ))}
      </div>
    );
  }
}

/* -------- App -------- */

class App extends React.Component {
  constructor() {
    super();

    this.state = {
      students: [],
      name: "",
      grade: "",
      filter: "all"
    };
  }

  componentDidMount() {
    console.log("Mounted");

    this.setState({
      students: [
        { id: 1, name: "Suraj", grade: 80 },
        { id: 2, name: "Rahul", grade: 40 }
      ]
    });
  }

  componentDidUpdate() {
    console.log("Updated");
  }

  componentWillUnmount() {
    console.log("Unmounted");
  }

  addStudent = (e) => {
    e.preventDefault();

    const { name, grade } = this.state;

    if (name === "" || grade === "") return;
    if (grade < 0 || grade > 100) return;

    const newStudent = {
      id: Date.now(),
      name,
      grade: Number(grade)
    };

    this.setState({
      students: [...this.state.students, newStudent],
      name: "",
      grade: ""
    });
  };

  deleteStudent = (id) => {
    this.setState({
      students: this.state.students.filter(s => s.id !== id)
    });
  };

  toggleStatus = (id) => {
    this.setState({
      students: this.state.students.map(s =>
        s.id === id
          ? { ...s, grade: s.grade >= 50 ? 40 : 80 }
          : s
      )
    });
  };

  render() {
    let filtered = this.state.students;

    if (this.state.filter === "pass") {
      filtered = filtered.filter(s => s.grade >= 50);
    }

    if (this.state.filter === "fail") {
      filtered = filtered.filter(s => s.grade < 50);
    }

    return (
      <div className="container">
        <h1>Student Grade Tracker</h1>

        {/* Form */}
        <form onSubmit={this.addStudent}>
          <input
            placeholder="Name"
            value={this.state.name}
            onChange={(e) => this.setState({ name: e.target.value })}
          />

          <input
            type="number"
            placeholder="Grade"
            value={this.state.grade}
            onChange={(e) => this.setState({ grade: e.target.value })}
          />

          <button>Add</button>
        </form>

        {/* Filter */}
        <div className="filter">
          <button onClick={() => this.setState({ filter: "all" })}>All</button>
          <button onClick={() => this.setState({ filter: "pass" })}>Passed</button>
          <button onClick={() => this.setState({ filter: "fail" })}>Failed</button>
        </div>

        {/* List */}
        <StudentList
          students={filtered}
          onDelete={this.deleteStudent}
          onToggle={this.toggleStatus}
        />
      </div>
    );
  }
}

/* -------- Render -------- */

ReactDOM.createRoot(document.getElementById("root")).render(<App />);