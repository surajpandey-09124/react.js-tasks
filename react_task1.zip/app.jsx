import React, { useState } from "react";
import ReactDOM from "react-dom/client";
import "./App.css";

/* -------- Portfolio -------- */

function PortfolioCard() {
  const images = [
    "https://i.pravatar.cc/150?img=1",
    "https://i.pravatar.cc/150?img=2",
    "https://i.pravatar.cc/150?img=3",
  ];

  const skills = ["HTML", "CSS", "JavaScript", "React"];

  const [index, setIndex] = useState(0);
  const [dark, setDark] = useState(false);
  const [likes, setLikes] = useState(0);

  return (
    <div className={dark ? "card dark" : "card"}>
      <img src={images[index]} />

      <h2>Suraj Pandey</h2>
      <h4>Frontend Developer</h4>

      <p>Learning React and building projects.</p>

      <div>
        {skills.map((s, i) => (
          <span key={i} className="skill">{s}</span>
        ))}
      </div>

      <button onClick={() => setDark(!dark)}>Theme</button>
      <button onClick={() => setIndex((index + 1) % images.length)}>Photo</button>
      <button onClick={() => alert("Hello 🔥")}>Alert</button>
      <button onClick={() => setLikes(likes + 1)}>❤️ {likes}</button>
    </div>
  );
}

/* -------- Movie -------- */

const moviesData = [
  { id: 1, title: "Inception" },
  { id: 2, title: "Batman" },
  { id: 3, title: "Avengers" },
];

function MovieApp() {
  const [search, setSearch] = useState("");
  const [fav, setFav] = useState([]);

  const filtered = moviesData.filter((m) =>
    m.title.toLowerCase().includes(search.toLowerCase())
  );

  const toggleFav = (id) => {
    if (fav.includes(id)) {
      setFav(fav.filter((f) => f !== id));
    } else {
      setFav([...fav, id]);
    }
  };

  return (
    <div className="movie">
      <h2>Movie Explorer</h2>

      <input
        type="text"
        placeholder="Search..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />

      {search === "" ? (
        <p>Type to search...</p>
      ) : filtered.length === 0 ? (
        <p>No results</p>
      ) : (
        filtered.map((m) => (
          <div key={m.id} className="movie-card">
            <span>{m.title}</span>
            <button onClick={() => toggleFav(m.id)}>
              {fav.includes(m.id) ? "💔" : "❤️"}
            </button>
          </div>
        ))
      )}

      <h3>Favourites</h3>
      {moviesData
        .filter((m) => fav.includes(m.id))
        .map((m) => (
          <p key={m.id}>{m.title}</p>
        ))}
    </div>
  );
}

/* -------- App -------- */

function App() {
  return (
    <>
      <PortfolioCard />
      <MovieApp />
    </>
  );
}

/* -------- Render -------- */

ReactDOM.createRoot(document.getElementById("root")).render(
  <App />
);