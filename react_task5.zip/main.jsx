// main.jsx (ALL IN ONE - Custom Hooks + LocalStorage)

import React, { useState, useEffect } from "react";
import ReactDOM from "react-dom/client";
import "./style.css";

/* -------- CUSTOM HOOK: LocalStorage -------- */

function useLocalStorage(key, initialValue) {
  const [value, setValue] = useState(() => {
    const saved = localStorage.getItem(key);
    return saved ? JSON.parse(saved) : initialValue;
  });

  useEffect(() => {
    localStorage.setItem(key, JSON.stringify(value));
  }, [key, value]);

  return [value, setValue];
}

/* -------- CUSTOM HOOK: Expenses -------- */

function useExpenses() {
  const [expenses, setExpenses] = useLocalStorage("expenses", []);

  const addExpense = (exp) => {
    setExpenses([...expenses, { ...exp, id: Date.now() }]);
  };

  const deleteExpense = (id) => {
    setExpenses(expenses.filter(e => e.id !== id));
  };

  return { expenses, addExpense, deleteExpense };
}

/* -------- COMPONENTS -------- */

function ExpenseForm({ addExpense }) {
  const [title, setTitle] = useState("");
  const [amount, setAmount] = useState("");
  const [category, setCategory] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!title || !amount) return;

    addExpense({
      title,
      amount: Number(amount),
      category,
      date: new Date().toLocaleDateString()
    });

    setTitle("");
    setAmount("");
    setCategory("");
  };

  return (
    <form onSubmit={handleSubmit}>
      <input placeholder="Title" value={title} onChange={e => setTitle(e.target.value)} />
      <input type="number" placeholder="Amount" value={amount} onChange={e => setAmount(e.target.value)} />
      <input placeholder="Category" value={category} onChange={e => setCategory(e.target.value)} />
      <button>Add</button>
    </form>
  );
}

function ExpenseList({ expenses, deleteExpense }) {
  return (
    <div>
      {expenses.map(e => (
        <div key={e.id} className="item">
          <span>{e.title} - ₹{e.amount} ({e.category})</span>
          <button onClick={() => deleteExpense(e.id)}>Delete</button>
        </div>
      ))}
    </div>
  );
}

function Summary({ expenses }) {
  const total = expenses.reduce((sum, e) => sum + e.amount, 0);

  return <h3>Total: ₹{total}</h3>;
}

function Filters({ setFilter }) {
  return (
    <div>
      <button onClick={() => setFilter("all")}>All</button>
      <button onClick={() => setFilter("food")}>Food</button>
      <button onClick={() => setFilter("travel")}>Travel</button>
    </div>
  );
}

/* -------- APP -------- */

function App() {
  const { expenses, addExpense, deleteExpense } = useExpenses();
  const [filter, setFilter] = useState("all");

  const filtered =
    filter === "all"
      ? expenses
      : expenses.filter(e => e.category.toLowerCase() === filter);

  return (
    <div className="container">
      <h1>Expense Tracker</h1>

      <ExpenseForm addExpense={addExpense} />
      <Filters setFilter={setFilter} />
      <Summary expenses={filtered} />
      <ExpenseList expenses={filtered} deleteExpense={deleteExpense} />
    </div>
  );
}

/* -------- RENDER -------- */

ReactDOM.createRoot(document.getElementById("root")).render(<App />);