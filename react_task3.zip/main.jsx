// main.jsx (ALL IN ONE - Weather Dashboard)

import React, { useState, useEffect } from "react";
import ReactDOM from "react-dom/client";
import "./App.css";

function App() {
  const [city, setCity] = useState("Delhi");
  const [input, setInput] = useState("");
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // 🔥 Fetch Weather
  useEffect(() => {
    if (!city) return;

    setLoading(true);
    setError("");

    const controller = new AbortController();

    fetch(
      `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=YOUR_API_KEY&units=metric`,
      { signal: controller.signal }
    )
      .then(res => {
        if (!res.ok) throw new Error("City not found");
        return res.json();
      })
      .then(data => {
        setData(data);
        setLoading(false);
      })
      .catch(err => {
        if (err.name !== "AbortError") {
          setError(err.message);
          setLoading(false);
        }
      });

    // 🔥 Cleanup
    return () => controller.abort();
  }, [city]);

  // 🔥 Auto refresh every 60s
  useEffect(() => {
    const interval = setInterval(() => {
      if (city) setCity(prev => prev);
    }, 60000);

    return () => clearInterval(interval);
  }, [city]);

  const handleSearch = () => {
    if (input.trim() !== "") {
      setCity(input);
      setInput("");
    }
  };

  return (
    <div className="container">
      <h1>Weather Dashboard</h1>

      <div className="search">
        <input
          value={input}
          onChange={e => setInput(e.target.value)}
          placeholder="Enter city..."
        />
        <button onClick={handleSearch}>Get Weather</button>
      </div>

      {loading && <p>Loading weather data...</p>}
      {error && <p className="error">{error}</p>}

      {data && !loading && (
        <div className="card">
          <h2>{data.name}</h2>
          <p>🌡 Temp: {data.main.temp} °C</p>
          <p>🌥 Condition: {data.weather[0].main}</p>
          <p>💧 Humidity: {data.main.humidity}%</p>
          <p>🌬 Wind: {data.wind.speed} m/s</p>
        </div>
      )}
    </div>
  );
}

/* -------- Render -------- */

ReactDOM.createRoot(document.getElementById("root")).render(
  <App />
);